-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2025 at 02:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wp_projekat2`
--

-- --------------------------------------------------------

--
-- Table structure for table `novosti`
--

DROP TABLE IF EXISTS `novosti`;
CREATE TABLE `novosti` (
  `id` int(11) NOT NULL,
  `naslov` varchar(255) NOT NULL,
  `sadrzaj` text NOT NULL,
  `autor_id` int(11) NOT NULL,
  `datum` date DEFAULT curdate(),
  `slika` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `novosti`
--

INSERT INTO `novosti` (`id`, `naslov`, `sadrzaj`, `autor_id`, `datum`, `slika`) VALUES
(1, 'Nova zvijezda na crvenom tepihu', 'Danas predstavljamo novog glumca...', 1, '2025-01-04', NULL),
(2, 'Top 10 albuma 2025. godine', 'Evo liste najboljih albuma ove godine...', 2, '2025-01-03', NULL),
(3, 'Nova pjesma Adele obara rekorde', 'Adele je ponovo zapanjila obožavatelje širom svijeta novim singlom, koji je već na putu da obori sve muzičke rekorde. Pjesma \"Easy on Me\" je postala najbrže prodavana na digitalnim platformama.', 1, '2025-01-07', 'adele.jpg'),
(4, 'Glumačka ekipa serije \"Stranger Things\" otkrila tajne iza scene', 'Ekipa popularne serije \"Stranger Things\" u intervjuu je podijelila svoja iskustva sa snimanja, govoreći o izazovima, prijateljstvima i najuzbudljivijim trenucima koji nisu bili prikazani u samoj seriji.', 2, '2025-01-06', 'stranger_things.jpg'),
(5, 'Predstavljanje novih filmskih tehnologija', 'Filmska industrija se stalno razvija, a nove tehnologije donose revoluciju u načinu na koji gledamo filmove. Najnoviji trenuci uključuju korištenje virtualne stvarnosti, napredne CGI tehnike, i inovativne kamere koje omogućuju snimanje u visokom kvalitetu.', 1, '2025-01-07', 'filmska_tehnologija.jpg'),
(6, 'Obnova klasičnih filmova', 'Mnogi klasični filmovi ponovo se pojavljuju u kinima nakon restauracije. Tehnologija omogućava da stare snimke budu obnovljene u visokoj definiciji, čineći ih ponovo dostupnim novim generacijama.', 2, '2025-01-06', 'obnova_filmova.jpg'),
(7, 'Premijera najnovijeg blockbustera', 'Novi blockbuster “Zadnji izlazak” donosi uzbudljive akcijske scene i nevjerojatnu vizualnu umjetnost. Film je već izazvao veliku pažnju među kritičarima i publikom.', 6, '2025-01-05', 'blockbuster_premijera.jpg'),
(8, 'Tajna iza najvećih filmskih efekata', 'Kreatori najvećih filmskih efekata otkrivaju kako su postigli magiju na ekranu. Koristeći najnovije tehnološke napretke, filmski studio Marvel je postavio nove standarde u industriji.', 1, '2025-01-04', 'filmski_efekti.jpg'),
(9, 'Gledanje filmova u 3D-u', '3D tehnologija ponovno postaje popularna u kinima, nudeći gledateljima nevjerojatno iskustvo i dubinu slike koja poboljšava vizualnu dimenziju filma.', 2, '2025-01-03', '3d_filmovima.jpg'),
(10, 'Filmovi sa digitalnim formatima', 'Prelazak sa analognih na digitalne kamere omogućio je filmskoj industriji da snima s izuzetnom preciznošću i kvalitetom. Ova tehnologija je sada standard u industriji.', 6, '2025-01-02', 'digitalni_filmovi.jpg'),
(11, 'Tehnološke inovacije u postprodukciji', 'Tehnologija koja se koristi u postprodukciji filmova omogućava nevjerojatnu preciznost u montaži, kolor korekciji i dodavanju specijalnih efekata, što poboljšava krajnji proizvod.', 1, '2025-01-01', 'postprodukcija.jpg'),
(12, 'Razvoj filmskih studija u svijetu', 'Filming studios širom svijeta ulažu u novu infrastrukturu koja koristi najnovije tehnologije, uključujući umjetničku inteligenciju i robotiku, kako bi unaprijedili proces snimanja i produkcije.', 2, '2024-12-31', 'filmski_studiji.jpg'),
(13, 'Nove tehnologije u filmovima za djecu', 'Nove animacijske tehnike i tehnologije omogućavaju stvaranje živopisnih svjetova i likova koji privlače mladu publiku, stvarajući potpuno novo iskustvo gledanja filmova za djecu.', 6, '2024-12-30', 'filmovi_za_djecu.jpg'),
(14, 'Upotreba dronova u snimanju filmova', 'Dronovi se sve češće koriste za snimanje filmova, omogućujući snimateljima da dođu do nevjerojatnih kutova i snimaju scene koje su ranije bile gotovo nemoguće.', 1, '2024-12-29', 'dronovi_u_filmu.jpg'),
(15, 'Budućnost filmskih festivala', 'Filmski festivali širom svijeta počinju koristiti VR i AR tehnologije kako bi obogatili iskustvo gledatelja i omogućili im da dožive filmove na potpuno nov način.', 2, '2024-12-28', 'filmski_festivali.jpg'),
(16, 'Razvoj filmskog zvuka', 'Novi zvučni efekti i tehnologije surround zvuka omogućavaju filmovima da stvore realističan zvučni pejzaž koji poboljšava iskustvo gledanja i doživljaja filma.', 6, '2024-12-27', 'filmski_zvuk.jpg'),
(17, 'Filmovi u 8K kvaliteti', 'S novim 8K ekranima, filmski studiji sada mogu snimati u nevjerojatnoj rezoluciji, stvarajući neviđeni nivo detalja i oštrine slike koja zadovoljava najviše standarde kvalitete.', 1, '2024-12-26', '8k_filmovima.jpg'),
(18, 'Filmski scenariji i tehnologija', 'Kako tehnologija utječe na pisanje scenarija za filmove? Novije tehnologije pomažu piscima u analizi tržišta i predviđanju uspjeha filmova temeljenih na scenarijima.', 2, '2024-12-25', 'scenariji_tehnologija.jpg'),
(19, 'Razvoj filmskih specijalnih efekata', 'Specijalni efekti su ključni za moderne filmove, te su se razvijali zajedno sa tehnologijom...', 2, '2025-01-04', 'filmski_efekti.jpg'),
(20, 'Filmska premijera godine', 'Premijera najnovijeg filma izazvala je veliku pažnju, privukavši mnoge poznate ličnosti...', 6, '2025-01-03', 'premijera_godine.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `ime` varchar(50) DEFAULT NULL,
  `prezime` varchar(50) DEFAULT NULL,
  `korisnicko_ime` varchar(50) DEFAULT NULL,
  `sifra` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('korisnik','administrator') DEFAULT 'korisnik',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ime`, `prezime`, `korisnicko_ime`, `sifra`, `email`, `role`, `created_at`) VALUES
(1, 'Adna', 'Kovacevic', 'adna.k', '*2342D5BC21319E613F4BA27D72A756FD3007027A', 'adnakovacevic9@gmail.com', 'administrator', '2025-01-03 15:36:16'),
(2, 'Dzenita', 'Kapetanovic', 'dzenita.k', '*677CDD772E29AE4F404200C7553B866CA77AFA23', 'dzenitak@gmail.com', 'korisnik', '2025-01-03 15:36:16'),
(3, 'Amir', 'Hadžić', 'amir.had', 'sifra123', 'amir.hadic@email.com', 'korisnik', '2025-01-07 19:06:20'),
(4, 'Jasmin', 'Kovač', 'jasmin.kov', 'sifra456', 'jasmin.kov@email.com', 'korisnik', '2025-01-07 19:06:20'),
(5, 'Haris', 'Smajkić', 'haris.smaj', 'sifra789', 'haris.smaj@email.com', 'korisnik', '2025-01-07 19:06:20'),
(6, 'Amina', 'Osmanhodzic', 'amina.o', '*045B5C309BDDBF1771F28E00111A7580920F41FD', 'aminao@gmail.com', 'korisnik', '2025-01-03 15:54:41'),
(7, 'Adnan', 'Alić', 'adnan.ali', 'sifra234', 'adnan.ali@email.com', 'korisnik', '2025-01-07 19:06:20'),
(8, 'Selim', 'Ibrahimović', 'selim.ibra', 'sifra567', 'selim.ibra@email.com', 'korisnik', '2025-01-07 19:06:20'),
(9, 'Kenan', 'Hodžić', 'kenan.hodz', 'sifra890', 'kenan.hodz@email.com', 'korisnik', '2025-01-07 19:06:20'),
(10, 'Ahmed', 'Begović', 'ahmed.beg', 'sifra345', 'ahmed.beg@email.com', 'korisnik', '2025-01-07 19:06:20'),
(11, 'Idriz', 'Muhić', 'idriz.muh', 'sifra678', 'idriz.muh@email.com', 'korisnik', '2025-01-07 19:06:20'),
(12, 'Nihad', 'Zukić', 'nihad.zuk', 'sifra901', 'nihad.zuk@email.com', 'korisnik', '2025-01-07 19:06:20'),
(13, 'Tarik', 'Velić', 'tarik.vel', 'sifra112', 'tarik.vel@email.com', 'korisnik', '2025-01-07 19:06:20'),
(14, 'Aida', 'Begić', 'aida.beg', 'sifra113', 'aida.beg@email.com', 'korisnik', '2025-01-07 19:06:20'),
(15, 'Lejla', 'Memić', 'lejla.mem', 'sifra114', 'lejla.mem@email.com', 'korisnik', '2025-01-07 19:06:20'),
(16, 'Amra', 'Kadić', 'amra.kad', 'sifra115', 'amra.kad@email.com', 'korisnik', '2025-01-07 19:06:20'),
(17, 'Džana', 'Čengić', 'dzana.cen', 'sifra116', 'dzana.cen@email.com', 'korisnik', '2025-01-07 19:06:20'),
(18, 'Merisa', 'Đogić', 'merisa.dog', 'sifra117', 'merisa.dog@email.com', 'korisnik', '2025-01-07 19:06:20'),
(19, 'Selma', 'Jusufović', 'selma.jus', 'sifra118', 'selma.jus@email.com', 'korisnik', '2025-01-07 19:06:20'),
(20, 'Hana', 'Bajramović', 'hana.bajr', 'sifra119', 'hana.bajr@email.com', 'korisnik', '2025-01-07 19:06:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `novosti`
--
ALTER TABLE `novosti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `autor_id` (`autor_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `novosti`
--
ALTER TABLE `novosti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `novosti`
--
ALTER TABLE `novosti`
  ADD CONSTRAINT `novosti_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
